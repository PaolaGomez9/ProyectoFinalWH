
public class Indicador {
   private String Nombre;
   private float Valor;

    public Indicador(String Nombre, float Valor) {
        this.Nombre = Nombre;
        this.Valor = Valor;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public float getValor() {
        return Valor;
    }

    public void setValor(float Valor) {
        this.Valor = Valor;
    }
    
    
    
    
    
    
    
}
